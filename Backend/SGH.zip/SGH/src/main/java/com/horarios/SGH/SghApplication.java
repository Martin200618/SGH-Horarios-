package com.horarios.SGH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SghApplication {

	public static void main(String[] args) {
		SpringApplication.run(SghApplication.class, args);
	}

}
