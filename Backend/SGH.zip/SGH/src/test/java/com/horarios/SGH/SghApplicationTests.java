package com.horarios.SGH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SghApplicationTests {

	@Test
	void contextLoads() {
	}

}
